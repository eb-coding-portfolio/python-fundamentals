.. _api:

.. currentmodule:: pystan.misc

Conversion utilities for Stan's R Dump format
=============================================

.. autosummary::
   stan_rdump
   read_rdump

.. autofunction:: pystan.misc.stan_rdump

.. autofunction:: pystan.misc.read_rdump
